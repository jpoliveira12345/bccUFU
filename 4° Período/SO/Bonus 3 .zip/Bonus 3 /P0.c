#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <signal.h>
#include <time.h>
#include <semaphore.h>
#define MAX (11*sizeof(int))
struct mem_comp{
	int fila[10];
	int size;
	sem_t sema;
};

int main(){
	key_t senha=234;
	struct mem_comp *F1;
	void *memoria = (void*)0;
	int shmid = shmget(senha,MAX,0666|IPC_CREAT);
	if ( shmid == -1 ){ printf("shmget falhou\n"); exit(-1);}
	memoria = shmat(shmid,(void*)0,0);
	//atachment da memoria retorna um ponteiro para void da memoria
	if (memoria == (void *) -1 ){ printf("shmat falhou\n"); exit(-1);}
	F1 = (struct mem_comp*) memoria;
	sem_init(&(F1->sema),1,1);
	//casting do ponteiro para evitar o casting em todo acesso
	F1->size = 0;
	//incialização da fila
	srand(time(NULL));

	//produz umas merda pra mandar para F1
	while(1){
		if ((F1->size)<10){
			sem_wait(&(F1->sema));
			F1->fila[F1->size] = 1+rand()%1000;
			(F1->size)++;
			sem_post(&(F1->sema));
		}
	}
	//P4
	while(1){
		if(F1->size>0){
			printf("%d\n",F1->fila[F1->size]);
			F1->size--;
		}
	}
	
	return 0;
}
