#include <stdio.h>
#include <stdlib.h>
#include "matriz.h"
struct pesos{
    int custo;
    int capacidade;
    int delay;
    int trafego;
};

